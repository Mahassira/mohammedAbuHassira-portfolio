# Mohammed H. Abu Hassira — Cinematic Portfolio

Static HTML/CSS/JS portfolio.

## Run locally
Open `index.html` in a browser.

## GitHub Pages
1. Create a new GitHub repository.
2. Upload `index.html`, `style.css`, `script.js`, and the `assets` folder.
3. Go to Settings → Pages.
4. Select Deploy from a branch.
5. Choose `main` and `/root`.
6. Save.

The site is static and does not require a backend or paid hosting.
