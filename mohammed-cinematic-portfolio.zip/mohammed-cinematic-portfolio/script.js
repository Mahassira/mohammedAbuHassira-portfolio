document.getElementById('year').textContent = new Date().getFullYear();

var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

/* Nav show/hide */
var nav = document.getElementById('nav');
var hero = document.getElementById('hero');
var navObserver = new IntersectionObserver(function(entries){
  entries.forEach(function(e){ nav.classList.toggle('show', !e.isIntersecting); });
}, {threshold:0.15});
navObserver.observe(hero);

/* Generic reveal-on-scroll */
var revealEls = document.querySelectorAll('.reveal, .story-step, .data-step, .flow-node');
var revealObserver = new IntersectionObserver(function(entries){
  entries.forEach(function(entry){
    if(entry.isIntersecting){
      entry.target.classList.add('in');
    }
  });
}, {threshold:0.2, rootMargin:'0px 0px -60px 0px'});
revealEls.forEach(function(el){ revealObserver.observe(el); });

/* Sequential flow-node reveal within each project */
document.querySelectorAll('[data-flow]').forEach(function(flow){
  var nodes = flow.querySelectorAll('.flow-node');
  var flowObserver = new IntersectionObserver(function(entries){
    entries.forEach(function(entry){
      if(entry.isIntersecting){
        nodes.forEach(function(n, i){
          setTimeout(function(){ n.classList.add('in'); }, reduceMotion ? 0 : i * 180);
        });
        flowObserver.disconnect();
      }
    });
  }, {threshold:0.4});
  flowObserver.observe(flow);
});

/* Hero canvas — subtle connecting particle field representing Data -> Systems -> Automation -> Insight -> Growth */
(function(){
  var canvas = document.getElementById('hero-canvas');
  if(!canvas) return;
  var ctx = canvas.getContext('2d');
  var w, h, points = [];
  var accent = '227,167,61';
  var dim = '146,151,160';

  function resize(){
    w = canvas.width = canvas.offsetWidth * devicePixelRatio;
    h = canvas.height = canvas.offsetHeight * devicePixelRatio;
  }
  window.addEventListener('resize', resize);
  resize();

  var count = window.innerWidth < 700 ? 26 : 46;
  for(var i=0;i<count;i++){
    points.push({
      x: Math.random()*w, y: Math.random()*h,
      vx:(Math.random()-0.5)*0.25*devicePixelRatio, vy:(Math.random()-0.5)*0.25*devicePixelRatio,
      r: Math.random()*1.6+0.6
    });
  }

  function step(){
    ctx.clearRect(0,0,w,h);
    for(var i=0;i<points.length;i++){
      var p = points[i];
      p.x += p.vx; p.y += p.vy;
      if(p.x<0||p.x>w) p.vx*=-1;
      if(p.y<0||p.y>h) p.vy*=-1;
    }
    var maxDist = 160*devicePixelRatio;
    for(var i=0;i<points.length;i++){
      for(var j=i+1;j<points.length;j++){
        var dx = points[i].x-points[j].x, dy = points[i].y-points[j].y;
        var dist = Math.sqrt(dx*dx+dy*dy);
        if(dist < maxDist){
          var op = (1 - dist/maxDist) * 0.35;
          ctx.strokeStyle = 'rgba('+dim+','+op+')';
          ctx.lineWidth = 0.6*devicePixelRatio;
          ctx.beginPath();
          ctx.moveTo(points[i].x, points[i].y);
          ctx.lineTo(points[j].x, points[j].y);
          ctx.stroke();
        }
      }
    }
    for(var i=0;i<points.length;i++){
      var p = points[i];
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r*devicePixelRatio, 0, Math.PI*2);
      ctx.fillStyle = 'rgba('+(i%5===0?accent:dim)+',0.7)';
      ctx.fill();
    }
    if(!reduceMotion) requestAnimationFrame(step);
  }
  step();
})();
